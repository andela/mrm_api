from setuptools import setup
setup(
   name='nrm_tool',
   version='1.0',
   description='Meeting room management',
   author='Andela',
  
)